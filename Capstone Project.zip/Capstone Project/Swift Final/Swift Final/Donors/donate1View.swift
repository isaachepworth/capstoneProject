//
//  donate1View.swift
//  Swift Final
//
//  Created by Student on 1/5/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class donate1View: UIViewController {
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var cardTextField: UITextField!
    @IBOutlet weak var monthTextField: UITextField!
    @IBOutlet weak var yearTextField: UITextField!
    @IBOutlet weak var cvcTextField: UITextField!
    @IBOutlet weak var amountTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hideKeyboardWhenTappedAround()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func cardChanged(_ sender: Any) {
        let length = cardTextField.text?.count
        let card = cardTextField.text
        
        if (length! > 16){
            let index = card?.index((card?.startIndex)!, offsetBy: 16)
            cardTextField.text = String(cardTextField.text![..<index!])
        }
    }
    
    @IBAction func monthChanged(_ sender: Any) {
        let length = monthTextField.text?.count
        let month = monthTextField.text
        
        if (length! > 2){
            let index = month?.index((month?.startIndex)!, offsetBy: 2)
            monthTextField.text = String(monthTextField.text![..<index!])
        }
    }
    
    @IBAction func yearChanged(_ sender: Any) {
        let length = yearTextField.text?.count
        let year = yearTextField.text
        
        if (length! > 2){
            let index = year?.index((year?.startIndex)!, offsetBy: 2)
            yearTextField.text = String(yearTextField.text![..<index!])
        }
    }
    
    @IBAction func cvcChanged(_ sender: Any) {
        let length = cvcTextField.text?.count
        let cvc = cvcTextField.text
        
        if (length! > 3){
            let index = cvc?.index((cvc?.startIndex)!, offsetBy: 3)
            cvcTextField.text = String(cvcTextField.text![..<index!])
        }
    }
    
    @IBAction func amountEnd(_ sender: Any) {
        if let amount = Double(amountTextField.text!){
                amountTextField.text = "$" + String(format: "%.2f", arguments: [amount])
        }
    }
    
    @IBAction func submitButton(_ sender: UIButton) {
        //check with api that donation information is good, and that all information is correct
        performSegue(withIdentifier: "submitDonation", sender: self)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
