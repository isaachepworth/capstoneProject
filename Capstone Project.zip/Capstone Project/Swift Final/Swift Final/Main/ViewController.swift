//
//  ViewController.swift
//  Swift Final
//
//  Created by Student on 12/6/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var osuyoutubevideo: UIWebView!
    @IBOutlet weak var subscribeTextField: UITextField!
    var email = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        getVideo(videoCode: "wuQv3RwfXb0")
        hideKeyboardWhenTappedAround()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getVideo(videoCode:String){
        let url = URL(string: "https://www.youtube.com/embed/\(videoCode)")
        osuyoutubevideo.loadRequest(URLRequest(url: url!))
    }

    @IBAction func twitterbutton(_ sender: UIButton) {
        guard let url = URL(string: "https://twitter.com/OSUCedarCity") else {
            return
        }
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:]) {_ in }
        } else {
            // Fallback on earlier versions
            UIApplication.shared.openURL(url)
        }
    }
    
    @IBAction func youtubeButton(_ sender: UIButton) {
        guard let url = URL(string: "https://www.youtube.com/user/OrchestraofSouthernU") else {
            return
        }
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:]) {_ in }
        } else {
            // Fallback on earlier versions
            UIApplication.shared.openURL(url)
        }
    }
    
    @IBAction func facebookButton(_ sender: UIButton) {
        guard let url = URL(string: "https://www.facebook.com/groups/orchestraofsouthernutah/") else {
            return
        }
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:]) {_ in }
        } else {
            // Fallback on earlier versions
            UIApplication.shared.openURL(url)
        }
    }
    
    @IBAction func blogspotButton(_ sender: UIButton) {
        guard let url = URL(string: "http://osucedarcity.blogspot.com/") else {
            return
        }
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:]) {_ in }
        } else {
            // Fallback on earlier versions
            UIApplication.shared.openURL(url)
        }
    }
    
    @IBAction func subscribeButton(_ sender: UIButton) {
        
        // varify email here and subscribe to email list
        
        performSegue(withIdentifier: "thankYou", sender: self)
    }
    
    @IBAction func linkedinButton(_ sender: UIButton) {
        guard let url = URL(string: "https://www.linkedin.com/profile/view?id=193039580&authType=NAME_SEARCH&authToken=rCwT&locale=en_US&trk=tyah&trkInfo=clickedVertical%3Amynetwork%2Cidx%3A1-1-1%2CtarId%3A1428709953397%2Ctas%3AOrchestra+of+Southern+Utah") else {
            return
        }
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:]) {_ in }
        } else {
            // Fallback on earlier versions
            UIApplication.shared.openURL(url)
        }
    }
    
    /*@IBAction func subcribeButton(_ sender: UIButton) {
        if(subscribeTextField.text != ""){
            email = subscribeTextField.text!
            //send email location of subcription
            performSegue(withIdentifier: "subscribe", sender: self)
        }
        
    }*/
    
    
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
