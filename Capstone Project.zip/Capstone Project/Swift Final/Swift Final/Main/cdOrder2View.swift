//
//  cdOrder2View.swift
//  Swift Final
//
//  Created by Student on 1/5/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class cdOrder2View: UIViewController {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var zipTextField: UITextField!
    @IBOutlet weak var phoneNumTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func zipChanged(_ sender: Any) {
        let length = zipTextField.text?.count
        let zip = zipTextField.text
        
        if (length! > 5){
            let index = zip?.index((zip?.startIndex)!, offsetBy: 5)
            zipTextField.text = String(zipTextField.text![..<index!])
        }
    }
    
    @IBAction func submitButton(_ sender: UIButton) {
        
        performSegue(withIdentifier: "SubmitCdOrder", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

