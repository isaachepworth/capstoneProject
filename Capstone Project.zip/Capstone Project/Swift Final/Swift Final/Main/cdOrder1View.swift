//
//  cdOrder1View.swift
//  Swift Final
//
//  Created by Student on 1/5/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit
class cdOrder1View: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var dvdNumber: UITextField!
    @IBOutlet weak var cdNumber: UITextField!
    @IBOutlet weak var cvcTextField: UITextField!
    @IBOutlet weak var cardNumberTextFeld: UITextField!
    @IBOutlet weak var eMailTextField: UITextField!
    @IBOutlet weak var performanceTextField: UITextField!
    @IBOutlet weak var concertOrRecitalTextField: UITextField!
    @IBOutlet weak var MonthTextField: UITextField!
    @IBOutlet weak var yearTextField: UITextField!
    
    var totalCost = 0.00
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        
        //Do any additional setup after loading the view.
    }
    
    
    @IBAction func monthChanged(_ sender: Any) {
        let length = MonthTextField.text?.count
        let month = MonthTextField.text
        
        if (length! > 2){
            let index = month?.index((month?.startIndex)!, offsetBy: 2)
            MonthTextField.text = String(MonthTextField.text![..<index!])
        }
    }
    
    @IBAction func yearChanged(_ sender: Any) {
        let length = yearTextField.text?.count
        let year = yearTextField.text
        if (length! > 2){
            let index = year?.index((year?.startIndex)!, offsetBy: 2)
            yearTextField.text = String(yearTextField.text![..<index!])
        }
    }
    
    @IBAction func cardNumberChanged(_ sender: Any) {
        let length = cardNumberTextFeld.text?.count
        let card = cardNumberTextFeld.text
        
        if (length! > 16){
            let index = card?.index((card?.startIndex)!, offsetBy: 16)
            cardNumberTextFeld.text = String(cardNumberTextFeld.text![..<index!])
        }
    }
    
    @IBAction func cvcTextChanged(_ sender: Any) {
        let length = cvcTextField.text?.count
        let cvc = cvcTextField.text
        
        if (length! > 3){
            let index = cvc?.index((cvc?.startIndex)!, offsetBy: 3)
            cvcTextField.text = String(cvcTextField.text![..<index!])
        }
    }

    @IBAction func cdTextFieldButton(_ sender: Any) {
        if let cdDouble = Double(cdNumber.text!){
            if let dvdDouble = Double(dvdNumber.text!){
                totalCost = (dvdDouble * 25) + (cdDouble * 15)
                amountLabel.text = "$" + String(format: "%.2f", arguments: [(dvdDouble * 25) + (cdDouble * 15)])
            }else{
                totalCost = cdDouble * 15
                amountLabel.text = "$" + String(format: "%.2f", arguments: [cdDouble * 15])
            }
        }
    }
    
    @IBAction func dvdTextFieldButton(_ sender: Any) {
        if let dvdDouble = Double(dvdNumber.text!){
            if let cdDouble = Double(cdNumber.text!){
                totalCost = (dvdDouble * 25) + (cdDouble * 15)
                amountLabel.text = "$" + String(format: "%.2f", arguments: [(dvdDouble * 25) + (cdDouble * 15)])
            }else{
                totalCost = dvdDouble * 25
                amountLabel.text = "$" + String(format: "%.2f", arguments: [dvdDouble * 25])
            }
        }
    }
    
    @IBAction func nextButton(_ sender: UIButton) {
        //work with api for payment and only move on if good, also check that all field are valid
        performSegue(withIdentifier: "nextCdOrder", sender: self)
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


