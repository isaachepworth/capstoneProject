//
//  ticketsOrder1.swift
//  Swift Final
//
//  Created by Student on 1/17/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class ticketsOrder1: UIViewController {
    var concert = ""
    var cost = 0.00
    var totalCost = 0.00
    
    @IBOutlet weak var concertTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var cardTextField: UITextField!
    @IBOutlet weak var monthTextField: UITextField!
    @IBOutlet weak var yearTextField: UITextField!
    @IBOutlet weak var cvcTextFeld: UITextField!
    @IBOutlet weak var priceTextField: UILabel!
    @IBOutlet weak var numberOfTicketsTextField: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        concertTextField?.text = concert
        priceTextField?.text = "$" + String(format: "%.2f", arguments: [cost])
        totalCost = cost
        self.hideKeyboardWhenTappedAround()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func cardNumberChangedText(_ sender: UITextField) {
        let length = cardTextField.text?.count
        let card = cardTextField.text
        if (length! > 16){
            let index = card?.index((card?.startIndex)!, offsetBy: 16)
            cardTextField.text = String(cardTextField.text![..<index!])
        }
    }
    
    @IBAction func monthChangedText(_ sender: UITextField) {
        let length = monthTextField.text?.count
        let month = monthTextField.text
        if (length! > 2){
            let index = month?.index((month?.startIndex)!, offsetBy: 2)
            monthTextField.text = String(monthTextField.text![..<index!])
        }
    }
    
    @IBAction func yearChangedText(_ sender: UITextField) {
        let length = yearTextField.text?.count
        let year = yearTextField.text
        if (length! > 2){
            let index = year?.index((year?.startIndex)!, offsetBy: 2)
            yearTextField.text = String(yearTextField.text![..<index!])
        }
    }
    
    @IBAction func cvcChangedText(_ sender: UITextField) {
        let length = cvcTextFeld.text?.count
        let cvc = cvcTextFeld.text
        if (length! > 3){
            let index = cvc?.index((cvc?.startIndex)!, offsetBy: 3)
            cvcTextFeld.text = String(cvcTextFeld.text![..<index!])
        }
    }
    
    @IBAction func numberOfTickets(_ sender: UITextField) {
        if let ticketsDouble = Double(numberOfTicketsTextField.text!){
            totalCost = ticketsDouble * cost
            priceTextField.text = "$" + String(format: "%.2f", arguments: [ticketsDouble * cost])
        }
    }
    
    
    @IBAction func nextButton(_ sender: UIButton) {
        // take care of payment and varify all information is good
        
        performSegue(withIdentifier: "ticketOrderNext", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
