//
//  ticketsOrder2.swift
//  Swift Final
//
//  Created by Student on 1/17/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class ticketsOrder2: UIViewController {
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var adressText: UITextField!
    @IBOutlet weak var cityText: UITextField!
    @IBOutlet weak var stateText: UITextField!
    @IBOutlet weak var zipText: UITextField!
    @IBOutlet weak var phoneNumberText: UITextField!
    @IBOutlet weak var shipOrWillCallSegment: UISegmentedControl!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func zipChangedText(_ sender: UITextField) {
        let length = zipText.text?.count
        let card = zipText.text
        if (length! > 5){
            let index = card?.index((card?.startIndex)!, offsetBy: 5)
            zipText.text = String(zipText.text![..<index!])
        }
    }
    
    @IBAction func shipOrWillCall(_ sender: AnyObject) {
        switch shipOrWillCallSegment.selectedSegmentIndex
        {
        case 0:
            adressText.isHidden = false
            adressText.isUserInteractionEnabled = true
            cityText.isHidden = false
            cityText.isUserInteractionEnabled = true
            stateText.isHidden = false
            stateText.isUserInteractionEnabled = true
            zipText.isHidden = false
            zipText.isUserInteractionEnabled = true
        case 1:
            adressText.isHidden = true
            adressText.isUserInteractionEnabled = false
            cityText.isHidden = true
            cityText.isUserInteractionEnabled = false
            stateText.isHidden = true
            stateText.isUserInteractionEnabled = false
            zipText.isHidden = true
            zipText.isUserInteractionEnabled = false
        default:
            break
        }
    }
    
    @IBAction func submitButton(_ sender: UIButton) {
        // varify information and work with api to send info
        performSegue(withIdentifier: "ticketOrderSubmit", sender: self)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
